from django.shortcuts import render


def home(request):
    return render(request,'home.html')

def web(request):
    return render(request,'web.html')

def contact(request):
    return render(request,'contact.html')


def about(request):
    return render(request,'about.html')



def audio(request):
    return render(request,'audio.html')

def wearables(request):
    return render(request,'wearables.html')

def drones(request):
    return render(request,'drones.html')

def accessories(request):
    return render(request,'accessories.html')

def watches(request):
    return render(request,'watches.html')

def bags(request):
    return render(request,'bags.html')

def eyewear(request):
    return render(request,'eyewear.html')

def all_products(request):
    return render(request,'all_products.html')

def head_p(request):
    return render(request,'head_p.html')


def shop(request):
    return render(request,'shop.html')


def product_detail(request, product_id):
    # dummy product example, replace with actual DB query
    product = {
        "id": product_id,
        "name": "SkyVision Pro X1",
        "old_price": 899,
        "price": 764,
        "features": ["4K 60fps", "30min Flight", "3-axis Gimbal"]
    }

    if request.method == 'POST':
        phone = request.POST.get('phone')
        email = request.POST.get('email')
        payment = request.POST.get('payment')

        # simulate sending data to admin (you can replace with DB save or email)
        print(f"Order from {email} | Phone: {phone} | Product: {product['name']} | Payment: {payment}")

        # You can also email admin here
        # send_mail(subject, message, from_email, [admin_email])

        return render(request, 'thank_you.html', {'product': product})

    return render(request, 'product_detail.html', {'product': product})

